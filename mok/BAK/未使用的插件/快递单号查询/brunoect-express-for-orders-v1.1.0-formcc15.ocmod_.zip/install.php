<?php
// $query = $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "express_company`");

$query = $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "express_company` (
  `express_company_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `code` varchar(255) NOT NULL,
  `sort_order` tinyint(4) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`express_company_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8");


// $query = $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "express_company_to_store`");

$query = $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "express_company_to_store` (
  `express_company_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  PRIMARY KEY (`express_company_id`,`store_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");


$result = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "order` LIKE 'express_no'");
$exists = ($result->num_rows > 0)?TRUE:FALSE;
if (!$exists) {
	$query = $this->db->query("ALTER TABLE `" . DB_PREFIX . "order` ADD `express_company_id` INT NOT NULL , ADD `express_no` VARCHAR( 64 ) NOT NULL");
}
