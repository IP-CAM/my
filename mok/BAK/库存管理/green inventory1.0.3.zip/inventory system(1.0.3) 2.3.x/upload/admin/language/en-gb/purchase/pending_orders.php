<?php
// Heading
$_['heading_title']     = 'Pending Orders Report';

// Text
$_['text_list']         = 'Pending Orders List';

// Column
$_['column_order_id']   = 'Order ID';
$_['column_order_date'] = 'Order Date';
$_['column_total_products']          = 'Total Products';