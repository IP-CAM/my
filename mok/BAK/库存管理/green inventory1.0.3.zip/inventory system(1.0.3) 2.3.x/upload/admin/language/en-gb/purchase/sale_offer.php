<?php
$_['sale_chart_heading_text'] = "Sale Offer";

//filter

$_['all_products_text'] = "All Products";
$_['select_categor_text'] = "Select Category";
$_['select_option_text'] = "Select Option";
$_['select_option_value_text'] = "Select Option Value";
$_['sold_less_text'] = "Sold Less Than";

//columns

$_['column_product_name'] = "Prouct Name";
$_['column_category'] = "Category";
$_['column_option_value'] = "Option Value";
$_['column_stock'] = "Stock";
$_['column_sold'] = "Sold";

//button
$_['button_clear'] = "Clear";