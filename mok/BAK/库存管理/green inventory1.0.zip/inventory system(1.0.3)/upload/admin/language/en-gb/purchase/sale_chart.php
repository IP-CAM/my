<?php
$_['sale_chart_text'] = "Sale Comparison Chart";
$_['start_date_text'] = "Date Start";
$_['end_date_text'] = "Date End";

//button

$_['button_clear'] = "Clear";


//purchase 

$_['purchase_chart_text'] = "Purchase Comparison Chart";

/*dead chart*/
//entry

$_['entry_date_start'] = "Date Start";
$_['entry_date_end'] = "Date End";
$_['entry_dead_limit'] = "Dead Limit";


$_['dead_chart_text'] = "Dead Products Chart";

//button

$_['button_clear'] = "Clear";
/*dead chart*/