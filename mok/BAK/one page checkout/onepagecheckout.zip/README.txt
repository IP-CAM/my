# Onepagecheckout Module - OpenCart

Supported OpenCart Versions:
=============================

All 2.1.x.x, 2.2.x.x and 2.3.x.x  versions


Overview:
=================

Onepage Checkout is an opencart checkout page extension Built for making quikly purchases on your website.
it�s fully Dynamic Module which you have easy to customize Our checkout..


Main Features:
===============
* Fast and Quick Checkout Process
* Powerfull adminpanel
* All Form Feilds manage from adminpanel
* Easy to set sort out using drag funcationlly
* Full Multi Lanaguage and Manage from adminpanel
* Supports multistores
* Restore extensions Setting.
* Fast and smooth Loading
* Compatible on all major themes.
* Save your Time.
* Easy Installation and setup
* Uses OpenCart's built-in module system (no core files are overwritten)


How To Install It:
===================

See Documentation


How To Upgrade It:
===================

See UPGRADE.txt


Live Demo:
===========

You can try out Onepagecheckout Module without having to install.

Store Front: http://extensionsbazaar.com/onepagecheckout/
Admin Login: http://extensionsbazaar.com/onepagecheckout/admin/index.php?route=extension/module/onepagecheckout

Username: demo
Password: demo


Support and Suggestion
=========

Email: extensionsbazaar@gmail.com
